public class TwoFourTree {
    private class TwoFourTreeItem {
        int values = 1;
        int value1 = 0;                             // always exists.
        int value2 = 0;                             // exists iff the node is a 3-node or 4-node.
        int value3 = 0;                             // exists iff the node is a 4-node.
        boolean isLeaf = true;
        
        TwoFourTreeItem parent = null;              // parent exists iff the node is not root.
        TwoFourTreeItem leftChild = null;           // left and right child exist iff the note is a non-leaf.
        TwoFourTreeItem rightChild = null;          
        TwoFourTreeItem centerChild = null;         // center child exists iff the node is a non-leaf 3-node.
        TwoFourTreeItem centerLeftChild = null;     // center-left and center-right children exist iff the node is a non-leaf 4-node.
        TwoFourTreeItem centerRightChild = null;

        public boolean isTwoNode() {

            if(values == 1) {
                if (leftChild != null && rightChild != null) {
                    isLeaf = false;
                }return true;
            }

            else
                return false;

            /*

            return false;

             */
        }

        public boolean isThreeNode() {

            if(values == 2) {
                if(leftChild != null && rightChild != null) {
                    isLeaf = false;
                }
                return true;
            }
            else
                return false;

            /*
            if(leftChild != null && rightChild != null) {
                isLeaf = false;
                if (centerChild != null &&( centerLeftChild == null && centerRightChild == null)) {
                    return true;
                }
                return false;
            }
            return false;

             */
        }

        public boolean isFourNode() {

            if(values == 3){
                if(leftChild != null && rightChild != null) {
                    isLeaf = false;
                }
                return true;
            }
            else
                return false;

            /*
            if(leftChild != null && rightChild != null) {
                isLeaf = false;
                if (centerChild == null && (centerLeftChild != null && centerRightChild != null)) {
                    return true;
                }
                return false;
            }
            return false;

             */
        }

        public boolean isRoot() {
            if(parent==null) {
                return true;
            }
            return false;
        }

        public TwoFourTreeItem(int v1) {
            value1 = v1;
            values = 1;
        }

        public TwoFourTreeItem(int v1, int v2) {
            if(v1 <= v2){
                value1 = v1;
                value2 = v2;
                values = 2;
            }
            else{
                value1 = v2;
                value2 = v1;
                values = 2;
            }
            
        }

        public TwoFourTreeItem(int v1, int v2, int v3) {
            //value 1 <= 2
            if(v1 <= v2){
                if(v2 <= v3){
                    value1 = v1;
                    value2 = v2;
                    value3 = v3;
                    values = 3;
                }
                else if(v1 <= v3){
                    value1 = v1;
                    value2 = v3;
                    value3 = v2;
                    values = 3;
                }
                else{
                    value1 = v3;
                    value2 = v1;
                    value3 = v2;
                    values = 3;
                }


            }
            //value 1 > 2
            else{
                if(v1 <= v3){
                    value1 = v2;
                    value2 = v1;
                    value3 = v3;
                    values = 3;
                }
                else if(v3 <= v2){
                    value1 = v3;
                    value2 = v2;
                    value3 = v1;
                    values = 3;
                }
                else{
                    value1 = v2;
                    value2 = v3;
                    value3 = v1;
                    values = 3;
                }
            }
        }

        private void printIndents(int indent) {
            for(int i = 0; i < indent; i++) System.out.printf("  ");
        }

        public void printInOrder(int indent) {
            if(!isLeaf) leftChild.printInOrder(indent + 1);
            printIndents(indent);
            System.out.printf("%d\n", value1);
            if(isThreeNode()) {
                if(!isLeaf) centerChild.printInOrder(indent + 1);
                printIndents(indent);
                System.out.printf("%d\n", value2);
            } else if(isFourNode()) {
                if(!isLeaf) centerLeftChild.printInOrder(indent + 1);
                printIndents(indent);
                System.out.printf("%d\n", value2);
                if(!isLeaf) centerRightChild.printInOrder(indent + 1);
                printIndents(indent);
                System.out.printf("%d\n", value3);
            }
            if(!isLeaf) rightChild.printInOrder(indent + 1);
        }
    }

    TwoFourTreeItem root = null;

    public boolean addValue(int value) {
        //suppose this is a new tree, add to root
        if(root==null){
            root = new TwoFourTreeItem(value);
            return true;
        }

        //what if we have a root, and it had no child nodes?
        if(root.isLeaf){
            //check if values 2 and 3 exist. If so value 2 is the new root and 1,3 become children nodes.
            // Then we continue with adding current value.
            if(root.isFourNode()){
                split(root);
            }
            else if(root.isThreeNode()){
                if(value <= root.value1){
                    root.value3 = root.value2;
                    root.value2 = root.value1;
                    root.value1 = value;

                }
                else if(value <= root.value2){
                    root.value3 = root.value2;
                    root.value2 = value;
                }
                else{
                    root.value3 = value;
                }

                root.values++;
                return true;
            }
            else{
                if(value <= root.value1){
                    root.value2 = root.value1;
                    root.value1 = value;
                }
                else{
                    root.value2 = value;
                }
                root.values++;
                return true;
            }
        }
        //traverse the tree till we find where to put the value
        TwoFourTreeItem found = traverseDown(value);
        //System.out.println("\n Reached after traversal ");

        //check if it is a 2 node
        if(found.values == 1){
            if(value<found.value1){
                found.value2 = found.value1;
                found.value1 = value;
            }
            else{
                found.value2 = value;
            }
            found.values++;
        }

        //else it is a 3 node
        else{
            if(value <= found.value1){
                found.value3 = found.value2;
                found.value2 = found.value1;
                found.value1 = value;

            }
            else if(value <= found.value2){
                found.value3 = found.value2;
                found.value2 = value;
            }
            else{
                found.value3 = value;
            }
            found.values++;
        }

        return false;
    }

    //return node if we found the node to insert item at
    public TwoFourTreeItem traverseDown(int item){

        TwoFourTreeItem walker;
        walker = root;


        while(!walker.isLeaf){
            //check where item should go
            if(walker.isTwoNode()){
                if(item < walker.value1){
                    walker = walker.leftChild;
                }
                else{
                    walker = walker.rightChild;
                }
                //System.out.println("\n Reached Traversal 1 ");
            }
            else if(walker.isThreeNode()){
                if(item < walker.value1){
                    walker = walker.leftChild;
                }
                else if(item < walker.value2){
                    walker = walker.centerChild;
                }
                else{
                    walker = walker.rightChild;
                }
                //System.out.println("\n Reached Traversal 2 ");
            }
            //if we find a four node we split it
            else if(walker.isFourNode()){
                //System.out.println("\n Reached Traversal 3");
                if(!walker.isLeaf && !walker.isRoot() ){
                    split(walker);
                    walker = walker.parent;
                }
                else{
                    split(walker);
                }

                //System.out.println("\n Reached Traversal 4");
            }
            //System.out.println("\n Reached Traversal 5");
        }

        if(walker.isFourNode()){
            split(walker);
        }

        return walker;
    }

    public boolean traverseUp(int val){

        if(val == root.value1 || val == root.value2 || val == root.value3){
            return true;
        }
        TwoFourTreeItem walker = root;

        while(!walker.isLeaf){
            if(walker.isTwoNode()){

            }
            walker=walker.leftChild;
        }

        return false;
    }
    //split 4-node
    //returns true if split
    public boolean split(TwoFourTreeItem node){

        //if node to split is root then we make 2 children and pass on their respective values
        TwoFourTreeItem new1, new2;
        if(node.isRoot()){
            new1 = new TwoFourTreeItem(node.value1);
            new2 = new TwoFourTreeItem(node.value3);

            //if root doesn't have children, set new1 and 2 parent = root
            new1.parent = node;
            new2.parent = node;


            new1.leftChild = node.leftChild;
            new1.rightChild = node.centerLeftChild;

            new2.leftChild = node.centerRightChild;
            new2.rightChild = node.rightChild;

            node.leftChild = new1;
            node.rightChild = new2;
            node.centerRightChild = null;
            node.centerLeftChild = null;


            node.value1 = node.value2;
            node.value2 = 0;
            node.value3 = 0;
            node.values = 1;

            if(!node.isLeaf){
                new1.isLeaf = false;
                new2.isLeaf = false;

                new1.leftChild.parent = new1;
                new1.rightChild.parent = new1;

                new2.leftChild.parent = new2;
                new2.rightChild.parent = new2;

            }

            node.isLeaf = false;
            root.isLeaf = false;

            return true;

        }

        //send middle value to parent node.
        int send = node.value2;
        boolean isLeft = node.parent.leftChild == node;
        boolean isRight = node.parent.rightChild == node;
        boolean isCenter = node.parent.centerChild == node;

        if(node.parent.isTwoNode()) {
            //move value 2 up to parent first, then split the node
            if (send <= node.parent.value1) {
                node.parent.value2 = node.parent.value1;
                node.parent.value1 = send;

            }
            else{
                node.parent.value2 = send;

            }

            //split node now.
            //let's deal if the current node is a leaf node first
            if(node.isLeaf && isLeft){
                //move value 3 to center child
                new1 = new TwoFourTreeItem(node.value3);
                node.parent.centerChild = new1;
                new1.parent = node.parent;

                //set current code's values 2 and 3 to 0
                updateChild(node);

                //node.isLeaf = false;
                return true;
            }
            else if(node.isLeaf && isRight){
                //move value 3 to center child
                new2 = new TwoFourTreeItem(node.value1);
                node.parent.centerChild = new2;
                new2.parent = node.parent;
                node.value1 = node.value3;

                //set current code's values 2 and 3 to 0
                updateChild(node);

               // node.isLeaf = false;
                return true;
            }
            //if it isn't a leaf node
            else if(isLeft){
                //create new node for the parents left child to be
                new1 = new TwoFourTreeItem(node.value1);

                //fill new1 node's children
                new1.leftChild = node.leftChild;
                new1.rightChild = node.centerLeftChild;

                //node by the end must be a two node
                node.leftChild = node.centerRightChild;

                //have parent point to appropriate nodes
                node.parent.centerChild = node;
                node.parent.leftChild = new1;
                new1.parent = node.parent;

                //set node to a Two node format
                node.value1 = node.value3;
                updateChild(node);

                //node.isLeaf = false;
                return true;
            }
            else{
                //create new node for the parents left child to be
                new2 = new TwoFourTreeItem(node.value1);

                //fill new1 node's children
                new2.leftChild = node.centerRightChild;
                new2.rightChild = node.rightChild;

                //node by the end must be a two node
                node.rightChild = node.centerLeftChild;

                //have parent point to appropriate nodes
                node.parent.centerChild = node;
                node.parent.rightChild = new2;
                new2.parent = node.parent;

                //set node to a Two node format
                node.value1 = node.value3;
                updateChild(node);

               // node.isLeaf = false;
                return true;
            }


        }
        else if(node.parent.isThreeNode()) {
            //move value 2 up to head first then split
            if (send <= node.parent.value1) {
                node.parent.value3 = node.parent.value2;
                node.parent.value2 = node.value1;
                node.parent.value1 = send;
            } else if (send <= node.parent.value2) {
                node.parent.value3 = node.parent.value2;
                node.parent.value2 = send;
            } else {
                node.parent.value3 = send;
            }

            /////////////////////different section///////////////////////

            if (node.isLeaf && isLeft) {
                //new1 will be center left child and current node will stay left
                new1 = new TwoFourTreeItem(node.value3);
                node.parent.centerLeftChild = new1;
                node.parent.centerRightChild = node.parent.centerChild;
                node.parent.centerChild = null;
                new1.parent = node.parent;

                //set current code's values 2 and 3 to 0
                node.value2 = 0;
                node.value3 = 0;
                node.values = 1;
                node.parent.values++;

               // node.isLeaf = false;
                return true;
            } else if (node.isLeaf && isRight) {
                //new2 will be center right child and current node will still be the right child
                new2 = new TwoFourTreeItem(node.value1);
                node.parent.centerRightChild = new2;
                node.parent.centerLeftChild = node.parent.centerChild;
                node.parent.centerChild = null;
                new2.parent = node.parent;
                node.value1 = node.value3;

                //set current code's values 2 and 3 to 0
                node.value2 = 0;
                node.value3 = 0;
                node.values = 1;
                node.parent.values++;

                //node.isLeaf = false;
                return true;
            } else if (node.isLeaf && isCenter) {
                //move value 3 to center right child
                new2 = new TwoFourTreeItem(node.value3);
                node.parent.centerLeftChild = new2;
                new2.parent = node.parent;

                updateChild(node);

            }
            //has children nodes
            else if (isLeft) {
                //move value 3 to center left child
                new1 = new TwoFourTreeItem(node.value3);
                node.parent.centerLeftChild = new1;
                new1.parent = node.parent;

                //since our node is a 4-node we need to move the centerRightChild and RightChild to the new node
                new1.leftChild = node.centerRightChild;
                new1.rightChild = node.rightChild;

                node.rightChild = node.centerLeftChild;
                updateChild(node);
            }

            else if (isRight) {
                //move value 1 to center right child
                new2 = new TwoFourTreeItem(node.value1);
                node.parent.centerRightChild = new2;
                new2.parent = node.parent;

                new2.leftChild = node.leftChild;
                new2.rightChild = node.centerLeftChild;

                node.leftChild = node.centerRightChild;
                node.value1 = node.value3;

                updateChild(node);

                //node.isLeaf = false;
                return true;
            }
            //node is a Center child
            else {
                new2 = new TwoFourTreeItem(node.value3);
                node.parent.centerLeftChild = new2;
                node.parent.centerRightChild = node;
                node.parent.centerChild = null;
                new2.parent = node.parent;

                new2.leftChild = node.centerRightChild;
                new2.rightChild = node.rightChild;
                node.rightChild = node.centerLeftChild;

                updateChild(node);

                //node.isLeaf = false;
                return true;
            }

            //node.isLeaf = false;
        }

        return false;
    }

    public void updateChild(TwoFourTreeItem node){

        node.centerRightChild = null;
        node.centerLeftChild = null;
        node.centerChild = null;

        node.value2 = 0;
        node.value3 = 0;
        node.values =1;
        node.parent.values++;
    }

    //traverse the tree to check if it already contains a certain value
    public boolean hasValue(int value) {
        return false;
    }

    //deletes a node with a certain value
    public boolean deleteValue(int value) {
        return false;
    }

    public void printInOrder() {
        if(root != null) root.printInOrder(0);
    }

    public TwoFourTree() {

    }
}
